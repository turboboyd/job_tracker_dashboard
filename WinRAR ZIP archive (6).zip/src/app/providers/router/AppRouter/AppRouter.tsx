import React from "react";
import { Route, Routes } from "react-router-dom";

import { AppLayout } from "../layouts/AppLayout";
import { PublicOnly } from "../PublicOnly/PublicOnly";
import { RequireAuth } from "../RequireAuth/RequireAuth";
import {
  publicRoutes,
  privateRoutes,
  notFoundRoute,
} from "../routeConfig/routeConfig";

export const AppRouter: React.FC = () => {
  return (
    <React.Suspense
      fallback={
        <div className="h-screen w-full grid place-items-center text-sm text-muted-foreground">
          Loading…
        </div>
      }
    >
      <Routes>
        <Route element={<AppLayout />}>
          <Route element={<PublicOnly />}>
            {publicRoutes.map((route) => (
              <Route
                key={route.path}
                path={route.path}
                element={route.element}
              />
            ))}
          </Route>

          <Route element={<RequireAuth />}>
            {privateRoutes.map(({ path, element }) => (
              <Route key={path} path={path} element={element} />
            ))}
          </Route>

          <Route path={notFoundRoute.path} element={notFoundRoute.element} />
        </Route>
      </Routes>
    </React.Suspense>
  );
};