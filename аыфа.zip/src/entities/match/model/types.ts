import { LoopMatchStatus } from "src/entities/loop/model";

export type MatchStatus =
  | "new"
  | "applied"
  | "interview"
  | "offer"
  | "rejected";

export type Match = {
  id: string;

  userId: string;
  loopId: string;

  title: string;
  company: string;
  location: string;

  platform: string;
  url: string;
  description?: string;

  status: MatchStatus;
  matchedAt: string | null | undefined;

  createdAt: string;
  updatedAt: string;
};


export type DatePreset = "any" | "last7" | "last10" | "last14" | "last30" | "custom";

export type MatchesFiltersState = {
  q: string;
  loopId: "all" | string;
  platform: "all" | string;
  status: "all" | LoopMatchStatus;

  company: string;
  location: string;

  datePreset: DatePreset;
  dateFrom: string;
  dateTo: string;

  sort: "matchedAtDesc" | "matchedAtAsc" | "titleAsc" | "companyAsc";

  showAdvanced: boolean;
};

export const defaults: MatchesFiltersState = {
  q: "",
  loopId: "all",
  platform: "all",
  status: "all",
  company: "",
  location: "",

  datePreset: "any",
  dateFrom: "",
  dateTo: "",

  sort: "matchedAtDesc",
  showAdvanced: false,
};