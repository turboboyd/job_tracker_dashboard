export function buildHref(opts: { pathname: string; search?: string; hash?: string }): string {
  const s = opts.search ? (opts.search.startsWith("?") ? opts.search : `?${opts.search}`) : "";
  const h = opts.hash ? (opts.hash.startsWith("#") ? opts.hash : `#${opts.hash}`) : "";
  return `${opts.pathname}${s}${h}`;
}
