declare let __webpack_public_path__: string;

export const PUBLIC_PATH =
  typeof __webpack_public_path__ !== "undefined"
    ? __webpack_public_path__
    : "/";
