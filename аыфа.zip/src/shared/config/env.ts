export const FUNCTIONS_BASE_URL =
  "https://europe-west3-application-tracker-dashboard.cloudfunctions.net";
