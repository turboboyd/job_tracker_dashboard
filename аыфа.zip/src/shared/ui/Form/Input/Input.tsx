import React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { classNames } from "src/shared/lib";

export type InputPreset = "default" | "compact" | "comfortable" | "wide";

/**
 * Если хочешь оставить совместимость со старым API:
 * - preset + ручные оверрайды
 * - fullWidth как legacy, но лучше width
 */
export type InputProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> &
  VariantProps<typeof inputVariants> & {
    /** Готовый “пресет” — просто алиас набора вариантов */
    preset?: InputPreset;

    /** Legacy */
    fullWidth?: boolean;

    /**
     * Слоты:
     * - left / right: иконки, кнопки, clear, loader…
     * - rootClassName: стили контейнера (например, если хочешь w-full на контейнер)
     */
    leftSlot?: React.ReactNode;
    rightSlot?: React.ReactNode;
    rootClassName?: string;
  };

const inputVariants = cva(
  [
    // базовые
    "block",
    "bg-background text-foreground",
    "border border-input",
    "placeholder:text-muted-foreground",
    "outline-none",
    "shadow-sm",
    "transition-colors duration-fast ease-ease-out",

    // focus
    "focus-visible:ring-2 focus-visible:ring-ring",
    "focus-visible:ring-offset-2 focus-visible:ring-offset-background",

    // disabled
    "disabled:pointer-events-none disabled:opacity-50",
  ].join(" "),
  {
    variants: {
      size: {
        sm: "h-9 text-sm",
        md: "h-10 text-sm",
        lg: "h-11 text-sm",
      },

      radius: {
        md: "rounded-md",
        lg: "rounded-lg",
        xl: "rounded-xl",
      },

      paddingX: {
        xs: "px-xs", // 8px
        sm: "px-sm", // 12px
        md: "px-md", // 16px
      },

      width: {
        full: "w-full",
        auto: "w-auto",
      },

      state: {
        default: "",
        error: "border-destructive focus-visible:ring-destructive",
      },

      shadow: {
        none: "shadow-none",
        sm: "shadow-sm",
        md: "shadow-md",
      },
    },

    defaultVariants: {
      size: "md",
      radius: "xl",
      paddingX: "sm",
      width: "full",
      state: "default",
      shadow: "sm",
    },
  }
);

const inputRootVariants = cva("relative", {
  variants: {
    width: {
      full: "w-full",
      auto: "w-auto",
    },
  },
  defaultVariants: {
    width: "full",
  },
});

/**
 * Пресеты = алиасы к вариантам.
 * По твоей логике: compact => paddingX: md (16px).
 */
const presetMap: Record<InputPreset, Pick<VariantProps<typeof inputVariants>, "size" | "paddingX">> = {
  default: { size: "md", paddingX: "sm" },
  compact: { size: "sm", paddingX: "md" },
  comfortable: { size: "md", paddingX: "sm" },
  wide: { size: "lg", paddingX: "md" },
};

function hasSlot(node: React.ReactNode) {
  return node !== null && node !== undefined && node !== false;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      rootClassName,

      preset = "default",

      // variants (могут переопределить preset)
      size,
      radius,
      paddingX,
      width,
      state,
      shadow,

      // legacy
      fullWidth,

      // slots
      leftSlot,
      rightSlot,

      disabled,
      "aria-invalid": ariaInvalid,
      ...props
    },
    ref
  ) => {
    const presetDefaults = presetMap[preset];

    // preset -> дефолты, явные props -> приоритетнее
    const resolvedSize = size ?? presetDefaults.size;
    const resolvedPaddingX = paddingX ?? presetDefaults.paddingX;

    // width: если передали width — он главный
    // иначе: если fullWidth === false -> auto
    // иначе full
    const resolvedWidth: NonNullable<VariantProps<typeof inputVariants>["width"]> =
      width ?? (fullWidth === false ? "auto" : "full");

    const withLeft = hasSlot(leftSlot);
    const withRight = hasSlot(rightSlot);

    // Если есть слоты, нужно добавить padding слева/справа,
    // чтобы текст не залезал под иконки.
    // Значения под твои размеры можно легко расширять.
    const leftPadClass = withLeft
      ? resolvedSize === "sm"
        ? "pl-9"
        : resolvedSize === "lg"
          ? "pl-11"
          : "pl-10"
      : "";

    const rightPadClass = withRight
      ? resolvedSize === "sm"
        ? "pr-9"
        : resolvedSize === "lg"
          ? "pr-11"
          : "pr-10"
      : "";

    const invalid = ariaInvalid ?? (state === "error" ? true : undefined);

    // Если слотов нет — рендерим просто input (без лишнего div)
    if (!withLeft && !withRight) {
      return (
        <input
          ref={ref}
          disabled={disabled}
          aria-invalid={invalid}
          data-state={state ?? "default"}
          className={classNames(
            inputVariants({
              size: resolvedSize,
              radius,
              paddingX: resolvedPaddingX,
              width: resolvedWidth,
              state,
              shadow,
            }),
            className
          )}
          {...props}
        />
      );
    }

    // Если слоты есть — оборачиваем в контейнер
    return (
      <div className={classNames(inputRootVariants({ width: resolvedWidth }), rootClassName)}>
        {withLeft && (
          <div className="pointer-events-none absolute left-0 top-0 flex h-full items-center pl-sm text-muted-foreground">
            {leftSlot}
          </div>
        )}

        <input
          ref={ref}
          disabled={disabled}
          aria-invalid={invalid}
          data-state={state ?? "default"}
          className={classNames(
            inputVariants({
              size: resolvedSize,
              radius,
              paddingX: resolvedPaddingX,
              width: "full", 
              state,
              shadow,
            }),
            leftPadClass,
            rightPadClass,
            className
          )}
          {...props}
        />

        {withRight && (
          <div className="absolute right-0 top-0 flex h-full items-center pr-sm text-muted-foreground">
            {rightSlot}
          </div>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";
