import React from "react";

import type { FormikErrors, FormikTouched, FormikProps } from "formik";

import { getFieldError } from "src/shared/lib/form/getFieldError";

import { InputField, type InputFieldProps } from "./InputField";

type NameOf<T> = Extract<keyof T, string>;

export type FormikInputFieldProps<T> = Omit<
  InputFieldProps,
  "name" | "value" | "onChange" | "onBlur" | "error" | "id"
> & {
  formik: FormikProps<T>;
  name: NameOf<T>;

  /**
   * Если id не передан, используем name.
   */
  id?: string;

  /** Переопределить touched/errors (редко нужно) */
  touched?: FormikTouched<T>;
  errors?: FormikErrors<T>;
};

/**
 * FormikInputField — 1 строка вместо ручного aria, error, touched.
 */
export function FormikInputField<T>({
  formik,
  name,
  id,
  touched,
  errors,
  ...props
}: FormikInputFieldProps<T>) {
  const usedTouched = touched ?? formik.touched;
  const usedErrors = errors ?? formik.errors;

  const error = getFieldError<T>(name as keyof T, usedTouched, usedErrors);

  // Formik values могут быть не-строкой (например, number) — превращаем в string для input.
  const rawValue = (formik.values as any)?.[name];
  const value = rawValue === null || rawValue === undefined ? "" : String(rawValue);

  return (
    <InputField
      {...props}
      id={id ?? name}
      name={name}
      value={value}
      onChange={formik.handleChange}
      onBlur={formik.handleBlur}
      error={error}
    />
  );
}
