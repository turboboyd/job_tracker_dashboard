import React, { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

import { calculateStreak, streakLabel } from "src/shared/lib/streak/streak";
import type { StreakEvent } from "src/shared/lib/streak/streak";
import { Button, Card, LinkButton } from "src/shared/ui";

type Props = {
  events: StreakEvent[];
};

export const ProgressStreakCard: React.FC<Props> = ({ events }) => {
  const { t } = useTranslation();

  const streak = useMemo(() => calculateStreak(events), [events]);
  const label = useMemo(() => streakLabel(streak), [streak]);

  const hint =
    streak > 0
      ? t("home.streak.hint.on", "Keep it alive: one small action today.")
      : t("home.streak.hint.off", "Do one action today to start your streak.");

  const badgeClass =
    streak > 0
      ? "bg-success text-success-foreground border-transparent"
      : "bg-muted text-muted-foreground border-border";

  return (
    <Card className="p-5 sm:p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-xs text-muted-foreground">
            {t("home.streak.title", "Progress")}
          </div>

          <div className="mt-1 text-base font-semibold text-foreground">
            {t("home.streak.label", label)}
          </div>

          <div className="mt-1 text-sm text-muted-foreground">{hint}</div>
        </div>

        <div
          className={[
            "shrink-0 rounded-full border px-md py-1 text-xs font-medium",
            badgeClass,
          ].join(" ")}
        >
          {streak > 0
            ? t("home.streak.badge.on", "Active")
            : t("home.streak.badge.off", "Inactive")}
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-sm sm:flex-row">
        <LinkButton
          to="/login"
          variant="default"
          shadow="sm"
          size="lg"
          className="w-full sm:w-auto"
        >
          {t("home.streak.cta.signIn", "Sign in to track progress")}
        </LinkButton>
        <LinkButton
          to="/resources"
          variant="outline"
          size="lg"
          className="w-full sm:w-auto"
        >
          {t("home.streak.cta.tips", "Quick tips")}
        </LinkButton>
      </div>
    </Card>
  );
};
