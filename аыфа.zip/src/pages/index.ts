import { lazy } from "react";

import { Match } from './../entities/match/model/types';

export const MainPage = lazy(() => import("./MainPage/MainPage"));
export const AboutPage = lazy(() => import("./AboutPage/AboutPage"));
export const ResourcesPage = lazy(() => import("./ResourcesPage/ResourcesPage"));
export const LoginPage = lazy(() => import("./LoginPage/LoginPage"));
export const RegisterPage = lazy(() => import("./RegisterPage/RegisterPage"));

export const DashboardPage = lazy(() => import("./DashboardPage/DashboardPage"));
export const JobsPage = lazy(() => import("./JobsPage/JobsPage"));

export const ProfilePage = lazy(() => import("./ProfilePage/ProfilePage"));

export const ProfileQuestionsPage = lazy(() => import("./ProfileQuestionsPage/ProfileQuestionsPage"));

export const LoopsPage = lazy(() => import("./LoopsPage/LoopsPage"));

export const NotFoundPage = lazy(() => import("./NotFoundPage/NotFoundPage"));

export const WhatsNewPage = lazy(() => import("./WhatsNewPage/WhatsNewPage"));
export const MatchesPage = lazy(() => import("./MatchesPage/MatchesPage"));