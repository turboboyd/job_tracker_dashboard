import React, { useEffect, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useLocation, useNavigate } from "react-router-dom";

import { LoginForm } from "src/features/auth/ui/LoginForm/LoginForm";
import { useAuth } from "src/shared/lib";
import { Card, LinkButton } from "src/shared/ui";

type LocationState = { from?: { pathname?: string; search?: string } };

function getFrom(state: LocationState | null): string {
  const fromPath = state?.from?.pathname ?? "/dashboard";
  const fromSearch = state?.from?.search ?? "";
  return `${fromPath}${fromSearch}`;
}

const LoginPage: React.FC = () => {
  const { t } = useTranslation();
  const { isAuthenticated, isAuthReady } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = useMemo(
    () => getFrom(location.state as LocationState | null),
    [location.state]
  );

  useEffect(() => {
    if (isAuthReady && isAuthenticated) {
      navigate(from, { replace: true });
    }
  }, [isAuthReady, isAuthenticated, navigate, from]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md items-center justify-center px-4 py-12">
        <Card padding="md" shadow="sm" className="w-full rounded-3xl">
          <div className="space-y-2">
            <h1 className="text-xl font-semibold text-foreground">
              {t("auth.loginTitle")}
            </h1>
            <p className="text-sm leading-6 text-muted-foreground">
              {t("auth.loginSubtitle")}
            </p>
          </div>

          <div className="mt-6">
            <LoginForm
              onSuccess={(target) => navigate(target || from, { replace: true })}
            />
          </div>

          <div className="mt-6 space-y-2 text-center text-sm">
            <div className="text-muted-foreground">
              {t("auth.noAccount")}{" "}
              <LinkButton to="/register" variant="text" className="inline">
                {t("auth.createAccount")}
              </LinkButton>
            </div>

            <div>
              <LinkButton
                to="/"
                variant="text"
                className="inline text-muted-foreground"
              >
                {t("common.backToHome")}
              </LinkButton>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default LoginPage;
