import { useMemo } from "react";

import { useGetLoopQuery } from "src/entities/loop/api/loopApi";
import { joinTitles } from "src/entities/loop/lib";
import type { Loop } from "src/entities/loop/model";
import { LoopSearchLinks } from "src/entities/loop/ui/LoopSearchLinks/LoopSearchLinks";
import { normalizeError } from "src/shared/lib";
import { Button } from "src/shared/ui";

import { Header, CardText } from "./Header";

export function LoopDetailsView({
  userId,
  loopId,
  onBack,
}: {
  userId: string;
  loopId: string;
  onBack: () => void;
}) {
  const loopQ = useGetLoopQuery({ loopId });

  const loop: Loop | null = loopQ.data ?? null;

  const title = useMemo(() => loop?.name ?? "Loop", [loop?.name]);
  const subtitle = useMemo(() => {
    if (!loop)
      return "Change filters → Apply → links update and filters persist.";
    const roles = joinTitles(loop.titles) || "—";
    return `${roles} · ${loop.location} · ${
      loop.remoteMode === "remote_only" ? "Remote" : "Any"
    }`;
  }, [loop]);

  return (
    <div className="space-y-6">
      <Header
        title={title}
        subtitle={subtitle}
        right={
          <Button variant="outline" shape="lg" onClick={onBack}>
            Back
          </Button>
        }
      />

      {loopQ.isLoading ? (
        <CardText>Loading loop…</CardText>
      ) : loopQ.isError ? (
        <CardText>{normalizeError(loopQ.error)}</CardText>
      ) : !loop ? (
        <CardText>Loop not found.</CardText>
      ) : (
        <LoopSearchLinks
          userId={userId}
          loop={{
            id: loop.id,
            name: loop.name,
            titles: loop.titles,
            location: loop.location,
            radiusKm: loop.radiusKm,
            platforms: loop.platforms,
            remoteMode: loop.remoteMode,
            filters: loop.filters,
          }}
        />
      )}
    </div>
  );
}
