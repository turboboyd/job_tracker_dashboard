export default function BoardPage() {
  return (
    <div className="space-y-2">
      <div className="text-xl font-semibold text-foreground">Board</div>
      <div className="text-sm text-muted-foreground">
        Coming soon. Kanban board for your job pipeline.
      </div>
    </div>
  );
}
