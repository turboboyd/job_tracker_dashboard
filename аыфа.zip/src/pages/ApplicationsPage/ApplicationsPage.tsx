export default function ApplicationsPage() {
  return (
    <div className="space-y-2">
      <div className="text-xl font-semibold text-foreground">My applications</div>
      <div className="text-sm text-muted-foreground">
        Coming soon. Track submitted applications and statuses.
      </div>
    </div>
  );
}
