import { skipToken } from "@reduxjs/toolkit/query";
import React, { useMemo, useState } from "react";

import {
  useDeleteMatchMutation,
  useGetAllMatchesQuery,
  useUpdateMatchMutation,
  useUpdateMatchStatusMutation,
} from "src/entities/match/api/matchesApi";
import { useGetLoopsQuery } from "src/entities/loop/api/loopApi";
import type { LoopMatchStatus } from "src/entities/loop/model/types";
import { useAuth } from "src/shared/lib";
import { usePagination } from "src/shared/lib/pagination/usePagination";
import { notify, normalizeError } from "src/shared/lib";
import { Pagination } from "src/shared/ui/Pagination/Pagination";
import { getErrorMessage } from "src/shared/lib/errors";

import { Header, CardText } from "./components/LoopsHeader";

import { MatchesFilters } from "./components/MatchesFilters";
import { EditMatchModal } from "./components/EditMatchModal";
import { MatchCard } from "src/entities/match/ui/matchCard/MatchCard";
import { MatchesFiltersState } from "src/entities/match/model/types";

type SortKey = "matchedAtDesc" | "matchedAtAsc" | "titleAsc" | "companyAsc";

function norm(v: unknown): string {
  return String(v ?? "")
    .toLowerCase()
    .trim();
}
function cmpStr(a: string, b: string) {
  return a.localeCompare(b, undefined, { sensitivity: "base" });
}
function toTime(iso?: string | null): number {
  if (!iso) return -Infinity;
  const t = new Date(iso).getTime();
  return Number.isNaN(t) ? -Infinity : t;
}
function endOfDayMs(dateStr: string): number {
  const t = new Date(dateStr).getTime();
  if (Number.isNaN(t)) return NaN;
  return t + 24 * 60 * 60 * 1000 - 1;
}
function inDateRange(
  matchedAt: string | null | undefined,
  from: string,
  to: string
): boolean {
  if (!from && !to) return true;
  const t = toTime(matchedAt);
  if (t === -Infinity) return false;

  if (from) {
    const tf = new Date(from).getTime();
    if (!Number.isNaN(tf) && t < tf) return false;
  }
  if (to) {
    const tt = endOfDayMs(to);
    if (!Number.isNaN(tt) && t > tt) return false;
  }
  return true;
}

export default function MatchesPage() {
  const { user } = useAuth();
  const userId = user?.uid ?? null;

  const allQ = useGetAllMatchesQuery(userId ? { userId } : skipToken);
  const loopsQ = useGetLoopsQuery(userId ? { userId } : skipToken);

  const matches = allQ.data ?? [];
  const loops = loopsQ.data ?? [];

  const [updateStatus, updStatus] = useUpdateMatchStatusMutation();
  const [updateMatch, updMatch] = useUpdateMatchMutation();
  const [deleteMatch, del] = useDeleteMatchMutation();
  const busy = updStatus.isLoading || updMatch.isLoading || del.isLoading;

  const [filters, setFilters] = useState<MatchesFiltersState>({
    q: "",
    loopId: "all",
    platform: "all",
    status: "all",
    company: "",
    location: "",
    datePreset: "any",
    dateFrom: "",
    dateTo: "",
    sort: "matchedAtDesc",
    showAdvanced: false,
  });

  const [editingId, setEditingId] = useState<string | null>(null);

  const loopIdToName = useMemo(() => {
    const m = new Map<string, string>();
    for (const l of loops) m.set(l.id, l.name);
    return m;
  }, [loops]);

  const platformOptions = useMemo(() => {
    const set = new Set<string>();
    for (const m of matches) set.add(String(m.platform ?? "").toLowerCase());
    return Array.from(set).filter(Boolean).sort(cmpStr);
  }, [matches]);

  const statusOptions = useMemo(() => {
    const set = new Set<string>();
    for (const m of matches) set.add(String(m.status ?? ""));
    return Array.from(set).filter(Boolean).sort(cmpStr) as LoopMatchStatus[];
  }, [matches]);

  const filtered = useMemo(() => {
    const q = norm(filters.q);
    const loopId = filters.loopId;
    const platform = filters.platform;
    const status = filters.status;

    const company = norm(filters.company);
    const location = norm(filters.location);

    let arr = matches;

    if (loopId !== "all") arr = arr.filter((m) => m.loopId === loopId);
    if (platform !== "all")
      arr = arr.filter(
        (m) => String(m.platform ?? "").toLowerCase() === platform
      );
    if (status !== "all") arr = arr.filter((m) => m.status === status);

    if (q) {
      arr = arr.filter((m) => {
        const hay = `${m.title} ${m.company} ${m.location} ${
          m.description ?? ""
        }`.toLowerCase();
        return hay.includes(q);
      });
    }

    if (company) arr = arr.filter((m) => norm(m.company).includes(company));
    if (location) arr = arr.filter((m) => norm(m.location).includes(location));

    if (filters.dateFrom || filters.dateTo) {
      arr = arr.filter((m) =>
        inDateRange(m.matchedAt ?? null, filters.dateFrom, filters.dateTo)
      );
    }

    const sorted = [...arr];
    const sort: SortKey = filters.sort;

    if (sort === "matchedAtDesc")
      sorted.sort((a, b) => toTime(b.matchedAt) - toTime(a.matchedAt));
    if (sort === "matchedAtAsc")
      sorted.sort((a, b) => toTime(a.matchedAt) - toTime(b.matchedAt));
    if (sort === "titleAsc")
      sorted.sort((a, b) => cmpStr(a.title ?? "", b.title ?? ""));
    if (sort === "companyAsc")
      sorted.sort((a, b) => cmpStr(a.company ?? "", b.company ?? ""));

    return sorted;
  }, [matches, filters]);

  const resetKey = useMemo(() => {
    return JSON.stringify({ userId, ...filters, count: filtered.length });
  }, [userId, filters, filtered.length]);

  const pagination = usePagination({
    totalItems: filtered.length,
    pageSize: 10,
    resetKey,
  });

  const pagedMatches = useMemo(() => {
    return filtered.slice(
      pagination.offset,
      pagination.offset + pagination.limit
    );
  }, [filtered, pagination.offset, pagination.limit]);

  const editingMatch = useMemo(() => {
    if (!editingId) return null;
    return matches.find((m) => m.id === editingId) ?? null;
  }, [editingId, matches]);

  const handleDelete = async (matchId: string) => {
    try {
      await deleteMatch({ userId: userId ?? "", matchId }).unwrap();
      notify("success", "Match deleted");
    } catch (err) {
      notify("error", `Failed to delete match: ${getErrorMessage(err)}`);
    }
  };

  const handleUpdateStatus = async (
    matchId: string,
    status: LoopMatchStatus
  ) => {
    try {
      await updateStatus({ userId: userId ?? "", matchId, status }).unwrap();
      notify("success", "Match updated");
    } catch (err) {
      notify("error", `Failed to update match: ${getErrorMessage(err)}`);
    }
  };

  const handleSaveEdit = async (
    matchId: string,
    patch: Record<string, unknown>
  ) => {
    try {
      await updateMatch({
        userId: userId ?? "",
        matchId,
        patch: patch as any,
      }).unwrap();
      notify("success", "Match saved");
      setEditingId(null);
    } catch (err) {
      notify("error", `Failed to save match: ${getErrorMessage(err)}`);
      throw err;
    }
  };

  return (
    <div className="mx-auto">
      <Header title="Matches" subtitle="All matches across all your loops." />

      {allQ.isLoading ? (
        <CardText>Loading matches…</CardText>
      ) : allQ.isError ? (
        <CardText>{normalizeError(allQ.error)}</CardText>
      ) : matches.length === 0 ? (
        <CardText>No matches yet.</CardText>
      ) : (
        <>
          <MatchesFilters
            value={filters}
            onChange={setFilters}
            loopOptions={loops.map((l) => ({ id: l.id, name: l.name }))}
            platformOptions={platformOptions}
            statusOptions={statusOptions}
            totalCount={matches.length}
            filteredCount={filtered.length}
            loopsLoading={loopsQ.isLoading}
          />

          <div className="grid grid-cols-1 gap-md">
            {pagedMatches.map((m) => (
              <MatchCard
                key={m.id}
                match={m}
                loopName={loopIdToName.get(m.loopId) ?? ""}
                busy={busy}
                onUpdateStatus={handleUpdateStatus}
                onDelete={handleDelete}
                onEdit={() => setEditingId(m.id)}
              />
            ))}
          </div>

          <div className="flex justify-center pt-md">
            <Pagination
              page={pagination.page}
              totalPages={pagination.totalPages}
              onPageChange={pagination.setPage}
              disabled={busy}
            />
          </div>

          <EditMatchModal
            open={Boolean(editingMatch)}
            busy={busy}
            loopName={
              editingMatch ? loopIdToName.get(editingMatch.loopId) ?? "" : ""
            }
            match={editingMatch}
            onClose={() => setEditingId(null)}
            onSave={handleSaveEdit}
          />
        </>
      )}
    </div>
  );
}
