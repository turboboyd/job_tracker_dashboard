    import React, { useMemo, useState } from "react";

    import type { LoopMatchStatus } from "src/entities/loop/model/types";
    import { Button, Card, Modal } from "src/shared/ui";
    import { classNames } from "src/shared/lib";

    import type {
    MatchesFiltersState,
    DatePreset,
    } from "src/entities/match/model/types";



    import { TextField } from "./TextField";
    import { SelectField } from "./SelectField";




    function toISODate(d: Date) {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
    }

    function applyDatePreset(preset: DatePreset): {
    dateFrom: string;
    dateTo: string;
    } {
    if (preset === "any") return { dateFrom: "", dateTo: "" };
    if (preset === "custom") return { dateFrom: "", dateTo: "" };

    const days =
        preset === "last7"
        ? 7
        : preset === "last10"
        ? 10
        : preset === "last14"
        ? 14
        : 30;

    const to = new Date();
    const from = new Date();
    from.setDate(to.getDate() - days);

    return { dateFrom: toISODate(from), dateTo: toISODate(to) };
    }

    function Chip({
    children,
    onRemove,
    }: {
    children: React.ReactNode;
    onRemove: () => void;
    }) {
    return (
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1 text-xs text-foreground shadow-sm">
        <span className="truncate max-w-[220px]">{children}</span>
        <button
            type="button"
            onClick={onRemove}
            className="rounded-full px-2 py-0.5 text-muted-foreground hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Remove filter"
        >
            ✕
        </button>
        </span>
    );
    }

    export function MatchesFilters({
    value,
    onChange,
    loopOptions,
    platformOptions,
    statusOptions,
    totalCount,
    filteredCount,
    loopsLoading,
    }: {
    value: MatchesFiltersState;
    onChange: (next: MatchesFiltersState) => void;
    loopOptions: Array<{ id: string; name: string }>;
    platformOptions: string[];
    statusOptions: LoopMatchStatus[];
    totalCount: number;
    filteredCount: number;
    loopsLoading: boolean;
    }) {
    const [advancedOpen, setAdvancedOpen] = useState(false);

    const set = (patch: Partial<MatchesFiltersState>) =>
        onChange({ ...value, ...patch });

    const clear = () =>
        onChange({
        q: "",
        loopId: "all",
        platform: "all",
        status: "all",
        company: "",
        location: "",
        datePreset: "any",
        dateFrom: "",
        dateTo: "",
        sort: "matchedAtDesc",
        showAdvanced: false,
        });

    const active = useMemo(() => {
        const chips: Array<{ key: string; label: string; onRemove: () => void }> =
        [];

        if (value.q.trim())
        chips.push({
            key: "q",
            label: `Search: ${value.q}`,
            onRemove: () => set({ q: "" }),
        });

        if (value.loopId !== "all") {
        const name =
            loopOptions.find((l) => l.id === value.loopId)?.name ?? value.loopId;
        chips.push({
            key: "loopId",
            label: `Loop: ${name}`,
            onRemove: () => set({ loopId: "all" }),
        });
        }

        if (value.platform !== "all")
        chips.push({
            key: "platform",
            label: `Platform: ${String(value.platform).toUpperCase()}`,
            onRemove: () => set({ platform: "all" }),
        });

        if (value.status !== "all")
        chips.push({
            key: "status",
            label: `Status: ${String(value.status)}`,
            onRemove: () => set({ status: "all" }),
        });

        if (value.datePreset !== "any") {
        const label =
            value.datePreset === "custom"
            ? `Date: ${value.dateFrom || "?"} → ${value.dateTo || "?"}`
            : `Date: ${value.datePreset}`;
        chips.push({
            key: "datePreset",
            label,
            onRemove: () => set({ datePreset: "any", dateFrom: "", dateTo: "" }),
        });
        }


        if (value.company.trim())
        chips.push({
            key: "company",
            label: `Company: ${value.company}`,
            onRemove: () => set({ company: "" }),
        });
        if (value.location.trim())
        chips.push({
            key: "location",
            label: `Location: ${value.location}`,
            onRemove: () => set({ location: "" }),
        });

        if (value.sort !== "matchedAtDesc")
        chips.push({
            key: "sort",
            label: `Sort: ${value.sort}`,
            onRemove: () => set({ sort: "matchedAtDesc" }),
        });

        return { chips, count: chips.length, isDefault: chips.length === 0 };
    }, [value, loopOptions]);

    return (
        <>
        <Card variant="default" padding="sm" shadow="sm" className="space-y-md">
            <div className="flex flex-wrap items-center justify-between gap-md">
            <div className="text-sm text-muted-foreground">
                Showing{" "}
                <span className="font-medium text-foreground">{filteredCount}</span>{" "}
                of <span className="font-medium text-foreground">{totalCount}</span>
            </div>

            <div className="flex flex-wrap items-center gap-sm">
                <Button
                variant="outline"
                size="sm"
                shape="pill"
                shadow="sm"
                onClick={() => setAdvancedOpen(true)}
                >
                Advanced
                </Button>

                <Button
                variant="outline"
                size="sm"
                shape="pill"
                shadow="sm"
                disabled={active.isDefault}
                onClick={clear}
                >
                {active.count ? `Reset (${active.count})` : "Reset"}
                </Button>
            </div>
            </div>

            {active.chips.length ? (
            <div className="flex flex-wrap items-center gap-sm">
                {active.chips.map((c) => (
                <Chip key={c.key} onRemove={c.onRemove}>
                    {c.label}
                </Chip>
                ))}

                <button
                type="button"
                onClick={clear}
                className={classNames(
                    "ml-1 text-xs text-muted-foreground underline underline-offset-2",
                    "hover:text-foreground"
                )}
                >
                Clear all
                </button>
            </div>
            ) : null}

            {/* BASE ROWS */}
            <div className="grid grid-cols-1 gap-md md:grid-cols-6">
            <div className="md:col-span-3">
                <TextField
                label="Search"
                value={value.q}
                onChange={(q) => set({ q })}
                placeholder="Title, company, location, description…"
                inputSize="sm"
                />
            </div>

            <div className="md:col-span-1">
                <SelectField
                label="Loop"
                value={value.loopId}
                onChange={(loopId) => set({ loopId })}
                selectSize="sm"
                options={[
                    {
                    value: "all",
                    label: loopsLoading ? "Loading…" : "All loops",
                    },
                    ...loopOptions.map((l) => ({ value: l.id, label: l.name })),
                ]}
                />
            </div>

            <div className="md:col-span-1">
                <SelectField
                label="Platform"
                value={value.platform}
                onChange={(platform) => set({ platform })}
                selectSize="sm"
                options={[
                    { value: "all", label: "All platforms" },
                    ...platformOptions.map((p) => ({
                    value: p,
                    label: p.toUpperCase(),
                    })),
                ]}
                />
            </div>

            <div className="md:col-span-1">
                <SelectField
                label="Status"
                value={value.status}
                onChange={(status) => set({ status })}
                selectSize="sm"
                options={[
                    { value: "all", label: "All statuses" },
                    ...statusOptions.map((s) => ({ value: s, label: String(s) })),
                ]}
                />
            </div>
            </div>

            <div className="grid grid-cols-1 gap-md md:grid-cols-6">
            <div className="md:col-span-2">
                <SelectField
                label="Sort"
                value={value.sort}
                onChange={(sort) => set({ sort })}
                selectSize="sm"
                options={[
                    { value: "matchedAtDesc", label: "Matched date: newest" },
                    { value: "matchedAtAsc", label: "Matched date: oldest" },
                    { value: "titleAsc", label: "Title: A → Z" },
                    { value: "companyAsc", label: "Company: A → Z" },
                ]}
                />
            </div>

            <div className="md:col-span-2">
                <SelectField<DatePreset>
                label="Date"
                value={value.datePreset}
                onChange={(datePreset) => {
                    const patch = applyDatePreset(datePreset);
                    set({ datePreset, ...patch });
                }}
                selectSize="sm"
                options={[
                    { value: "any", label: "Any time" },
                    { value: "last7", label: "Last 7 days" },
                    { value: "last10", label: "Last 10 days" },
                    { value: "last14", label: "Last 14 days" },
                    { value: "last30", label: "Last 30 days" },
                    { value: "custom", label: "Custom range…" },
                ]}
                />
            </div>

            <div className="md:col-span-2 flex items-end justify-end">
                <Button
                variant="outline"
                size="sm"
                shape="pill"
                shadow="sm"
                onClick={() => setAdvancedOpen(true)}
                >
                More filters
                </Button>
            </div>
            </div>
        </Card>

        {/* ADVANCED MODAL */}
        <Modal
            open={advancedOpen}
            onOpenChange={setAdvancedOpen}
            size="lg"
            title="Advanced filters"
            description="Narrow down by company, location, and custom date range."
        >
            <div className="space-y-md">
            <div className="grid grid-cols-1 gap-md md:grid-cols-2">
                <TextField
                label="Company contains"
                value={value.company}
                onChange={(company) => set({ company })}
                placeholder="e.g. SAP"
                inputSize="sm"
                />
                <TextField
                label="Location contains"
                value={value.location}
                onChange={(location) => set({ location })}
                placeholder="e.g. Berlin"
                inputSize="sm"
                />
            </div>

            {value.datePreset === "custom" ? (
                <div className="grid grid-cols-1 gap-md md:grid-cols-2">
                <TextField
                    label="Date from"
                    value={value.dateFrom}
                    onChange={(dateFrom) => set({ dateFrom })}
                    type="date"
                    inputSize="sm"
                />
                <TextField
                    label="Date to"
                    value={value.dateTo}
                    onChange={(dateTo) => set({ dateTo })}
                    type="date"
                    inputSize="sm"
                />
                </div>
            ) : (
                <div className="text-sm text-muted-foreground">
                Tip: choose{" "}
                <span className="text-foreground font-medium">Custom range</span>{" "}
                in the Date filter to set exact dates.
                </div>
            )}

            <div className="flex items-center justify-end gap-sm">
                <Button
                variant="outline"
                size="sm"
                shape="pill"
                shadow="sm"
                onClick={() => setAdvancedOpen(false)}
                >
                Close
                </Button>
            </div>
            </div>
        </Modal>
        </>
    );
    }
