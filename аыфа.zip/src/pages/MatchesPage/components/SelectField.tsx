import React from "react";

import { classNames } from "src/shared/lib";
import { FormField } from "src/shared/ui";
import type {
  InputRadius,
  InputSize,
  InputState,
} from "src/shared/ui/Form/Input/Input";

type Option<T extends string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

type SelectFieldProps<T extends string> = {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;

  htmlFor?: string;

  value: T;
  onChange: (next: T) => void;

  options: Array<Option<T>>;

  disabled?: boolean;

  selectSize?: InputSize;
  radius?: InputRadius;
  state?: InputState;

  className?: string;

  selectProps?: Omit<
    React.SelectHTMLAttributes<HTMLSelectElement>,
    "value" | "onChange" | "disabled" | "className" | "children" | "size"
  >;
};

const sizeMap: Record<InputSize, string> = {
  sm: "h-9 px-sm text-sm",
  md: "h-10 px-sm text-sm",
  lg: "h-11 px-md text-sm",
};

const radiusMap: Record<InputRadius, string> = {
  md: "rounded-md",
  lg: "rounded-lg",
  xl: "rounded-xl",
};

export function SelectField<T extends string>({
  label,
  required,
  hint,
  error,
  htmlFor,

  value,
  onChange,
  options,

  disabled,

  selectSize = "md",
  radius = "xl",
  state,

  className,
  selectProps,
}: SelectFieldProps<T>) {
  const computedState: InputState = state ?? (error ? "error" : "default");

  return (
    <FormField
      label={label}
      required={required}
      hint={hint}
      error={error}
      htmlFor={htmlFor}
    >
      {({ id, describedBy, invalid }) => (
        <select
          id={id}
          aria-describedby={describedBy}
          aria-invalid={invalid}
          disabled={disabled}
          value={value}
          onChange={(e) => onChange(e.target.value as T)}
          className={classNames(
            "w-full bg-background text-foreground",
            "border border-input",
            "shadow-sm",
            "outline-none",
            "transition-colors duration-fast ease-ease-out",
            "focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            "disabled:pointer-events-none disabled:opacity-50",
            computedState === "error"
              ? "border-destructive focus-visible:ring-destructive"
              : "border-input",
            sizeMap[selectSize],
            radiusMap[radius],
            className
          )}
          {...(selectProps ?? {})}
        >
          {options.map((o) => (
            <option key={o.value} value={o.value} disabled={o.disabled}>
              {o.label}
            </option>
          ))}
        </select>
      )}
    </FormField>
  );
}
