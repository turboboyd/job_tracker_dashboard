import React from "react";

import type { Job, JobStatus } from "src/entities/job/model/types";
import { JobStatusDropdown } from "src/entities/job/ui/JobStatusDropdown/JobStatusDropdown";
import { normalizeError } from "src/shared/lib";
import { formatDate } from "src/shared/lib/date/formatDate";
import { Button } from "src/shared/ui";
import { Card } from "src/shared/ui/Card/Card";

import { JobsListSkeleton } from "./JobsListSkeleton";
import { JobsPagination } from "./JobsPagination";

type Props = {
  userId: string | null;

  title: string;
  subtitle?: string;

  isLoading: boolean;
  isError: boolean;
  error: unknown;

  jobsTotal: number;
  jobs: Job[];

  emptyByFilters: boolean;
  onResetFilters: () => void;

  onEdit: (job: Job) => void;

  onStatusChange: (args: { jobId: string; status: JobStatus }) => void;
  updatingJobId: string | null;

  page: number;
  totalPages: number;
  onPrevPage: () => void;
  onNextPage: () => void;
};

export function JobsListCard({
  userId,
  title,
  subtitle,

  isLoading,
  isError,
  error,

  jobsTotal,
  jobs,

  emptyByFilters,
  onResetFilters,

  onEdit,
  onStatusChange,
  updatingJobId,

  page,
  totalPages,
  onPrevPage,
  onNextPage,
}: Props) {
  return (
    <Card padding="md" shadow="sm" className="rounded-3xl">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-base font-semibold text-foreground break-words [hyphens:auto]">
            {title}
          </div>

          {subtitle ? (
            <div className="mt-1 text-sm leading-6 text-muted-foreground break-words [hyphens:auto]">
              {subtitle}
            </div>
          ) : null}

          <div className="mt-1 text-xs text-muted-foreground">
            Showing {jobs.length} of {jobsTotal}
          </div>
        </div>
      </div>

      {!userId ? (
        <div className="mt-4 rounded-xl border border-border bg-background p-4 text-sm text-muted-foreground">
          Sign in to see your jobs.
        </div>
      ) : isLoading ? (
        <div className="mt-4">
          <JobsListSkeleton rows={4} />
        </div>
      ) : isError ? (
        <div className="mt-4 rounded-xl border border-border bg-background p-4 text-sm text-muted-foreground">
          {normalizeError(error)}
        </div>
      ) : jobsTotal === 0 ? (
        <div className="mt-4 rounded-xl border border-border bg-background p-4 text-sm text-muted-foreground">
          No jobs yet.
        </div>
      ) : emptyByFilters ? (
        <div className="mt-4 rounded-xl border border-border bg-background p-4">
          <div className="text-sm text-muted-foreground">
            No results for current filters/search.
          </div>

          <div className="mt-3">
            <Button variant="outline" size="sm" shape="pill" onClick={onResetFilters}>
              Reset filters
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="mt-4 space-y-3">
            {jobs.map((j) => (
              <div
                key={j.id}
                className={[
                  "flex items-start justify-between gap-3",
                  "rounded-xl border border-border bg-background p-3",
                  "transition-all duration-200",
                  "motion-safe:hover:-translate-y-0.5",
                  "motion-safe:hover:shadow-[var(--shadow-sm)]",
                  "motion-safe:hover:bg-muted",
                ].join(" ")}
              >
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-foreground">
                    {j.title}
                  </div>
                  <div className="truncate text-xs text-muted-foreground">
                    {j.company}
                  </div>

                  <div className="mt-1 text-xs text-muted-foreground">
                    Created: {formatDate(j.createdAt)}
                    {j.updatedAt !== j.createdAt ? (
                      <> · Updated: {formatDate(j.updatedAt)}</>
                    ) : null}
                  </div>
                </div>

                <div className="flex shrink-0 flex-col items-end gap-2">
                  <JobStatusDropdown
                    mode="edit"
                    value={j.status}
                    disabled={updatingJobId === j.id}
                    onChange={(next) => onStatusChange({ jobId: j.id, status: next })}
                    size="sm"
                  />

                  <Button
                    variant="outline"
                    size="sm"
                    shape="pill"
                    onClick={() => onEdit(j)}
                  >
                    Edit
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <JobsPagination
              page={page}
              totalPages={totalPages}
              onPrev={onPrevPage}
              onNext={onNextPage}
            />
          </div>
        </>
      )}
    </Card>
  );
}
