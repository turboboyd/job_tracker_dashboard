export default function ProfileQuestionsPage() {
  return (
    <div className="space-y-2">
      <div className="text-xl font-semibold text-foreground">
        Profile questions
      </div>
      <div className="text-sm text-muted-foreground">
        Questions and answers for profile completion.
      </div>
    </div>
  );
}
