export default function ProfilePage() {
  return (
    <div className="space-y-2">
      <div className="text-xl font-semibold text-foreground">Profile</div>
      <div className="text-sm text-muted-foreground">
        Profile setup will be here.
      </div>
    </div>
  );
}
