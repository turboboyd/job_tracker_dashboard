declare const __PUBLIC_URL__: string;

export type WhatsNewItem = {
  tag: string;
  name?: string;
  url: string;
  bullets?: string[];
  date?: string; 
};


export type WhatsNewPayload = {
  items: WhatsNewItem[];
};

function normalizeBasePath(p: string): string {
  if (!p || p === "/") return "/";
  return p.endsWith("/") ? p : `${p}/`;
}

export async function fetchWhatsNew(signal?: AbortSignal): Promise<WhatsNewPayload> {
  const origin = typeof window !== "undefined" ? window.location.origin : "http://localhost";
  const basePath = normalizeBasePath(typeof __PUBLIC_URL__ !== "undefined" ? __PUBLIC_URL__ : "");
  const url = new URL(`${basePath}whats-new.json`, origin).toString();

  const res = await fetch(url, { signal, headers: { Accept: "application/json" } });

  if (!res.ok) throw new Error(`Failed to load whats-new.json (${res.status})`);

  const data = (await res.json()) as WhatsNewPayload;
  return { items: Array.isArray(data?.items) ? data.items : [] };
}
