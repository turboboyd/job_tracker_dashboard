import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";

import { Button, Card } from "src/shared/ui";

import { fetchWhatsNew, type WhatsNewItem } from "../api/fetchWhatsNew";

type Props = {
  mode?: "inline" | "full";
  maxBullets?: number;
};

function getSeenKey(): string {
  return "whatsNewSeenTag";
}

function formatDate(input?: string): string | null {
  if (!input) return null;

  // допускаем "YYYY-MM-DD" и ISO
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return null;

  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
  });
}

type WhatsNewEntryProps = {
  item: WhatsNewItem;
  maxBullets: number;
  mode: "inline" | "full";
  onMarkSeen?: (tag: string) => void;
};

const WhatsNewEntry: React.FC<WhatsNewEntryProps> = ({
  item,
  maxBullets,
  mode,
  onMarkSeen,
}) => {
  const { t } = useTranslation();

  const bullets = (item.bullets ?? []).slice(0, Math.max(0, maxBullets));
  const dateStr = formatDate(item.date);

  return (
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <div className="text-xs text-muted-foreground">
          {t("whatsNew.title", "What’s new")}
        </div>

        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
          <div className="text-sm font-semibold text-foreground">
            {item.name || item.tag}
          </div>

          {dateStr ? (
            <div className="text-xs text-muted-foreground">{dateStr}</div>
          ) : null}
        </div>

        <div className="mt-1 text-xs text-muted-foreground">
          {t("whatsNew.version", "Version")}: {item.tag}
        </div>

        {bullets.length ? (
          <div className="mt-3 space-y-2">
            {bullets.map((x: string, idx: number) => (
              <div
                key={`${item.tag}-${idx}`}
                className="flex items-start gap-2"
              >
                <span className="mt-2 inline-block h-1.5 w-1.5 rounded-full bg-foreground/60" />
                <div className="text-sm text-muted-foreground">{x}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-3 text-sm text-muted-foreground">
            {t("whatsNew.noNotes", "Release notes are empty for this version.")}
          </div>
        )}

        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <a
            href={item.url}
            target="_blank"
            rel="noreferrer"
            className="w-full sm:w-auto"
          >
            <Button variant="outline" shape="lg" className="w-full sm:w-auto">
              {t("whatsNew.viewOnGitHub", "View on GitHub")}
            </Button>
          </a>

          {mode === "full" && onMarkSeen ? (
            <Button
              variant="ghost"
              shape="lg"
              onClick={() => onMarkSeen(item.tag)}
              className="w-full sm:w-auto"
            >
              {t("whatsNew.markSeen", "Mark as seen")}
            </Button>
          ) : null}
        </div>
      </div>

      <div className="shrink-0 rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground">
        {t("whatsNew.badge", "update")}
      </div>
    </div>
  );
};

export const WhatsNewCard: React.FC<Props> = ({
  mode = "inline",
  maxBullets = 6,
}) => {
  const { t } = useTranslation();
  const [items, setItems] = useState<WhatsNewItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [dismissedInline, setDismissedInline] = useState(false);

  useEffect(() => {
    const ctrl = new AbortController();
    setLoading(true);
    setError(null);

    fetchWhatsNew(ctrl.signal)
      .then((payload) => {
        const list = Array.isArray(payload.items) ? payload.items : [];
        list.sort((a, b) => {
          const ta = a.date ? new Date(a.date).getTime() : 0;
          const tb = b.date ? new Date(b.date).getTime() : 0;
          return tb - ta; 
        });
        setItems(list);
      })
      .catch((e: unknown) => {
        const msg = e instanceof Error ? e.message : "Unknown error";
        setError(msg);
      })
      .finally(() => setLoading(false));

    return () => ctrl.abort();
  }, []);

  const latest = items[0];

  const seenTag = useMemo(() => {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(getSeenKey());
  }, []);

  const shouldShowInline = useMemo(() => {
    if (mode !== "inline") return true;
    if (!latest) return false;
    if (dismissedInline) return false;
    return seenTag !== latest.tag;
  }, [latest, mode, seenTag, dismissedInline]);

  const markSeen = (tag: string) => {
    if (typeof window === "undefined") return;
    localStorage.setItem(getSeenKey(), tag);

    if (mode === "inline") {
      setDismissedInline(true);
    }
  };

  if (loading) {
    return mode === "full" ? (
      <Card className="p-6">
        <div className="text-sm font-semibold text-foreground">
          {t("whatsNew.title", "What’s new")}
        </div>
        <div className="mt-2 text-sm text-muted-foreground">
          {t("whatsNew.loading", "Loading updates…")}
        </div>
      </Card>
    ) : null;
  }

  if (error) {
    return mode === "full" ? (
      <Card className="p-6">
        <div className="text-sm font-semibold text-foreground">
          {t("whatsNew.title", "What’s new")}
        </div>
        <div className="mt-2 text-sm text-muted-foreground">
          {t("whatsNew.error", "Could not load updates.")}
        </div>
        <div className="mt-1 text-xs text-muted-foreground">{error}</div>
      </Card>
    ) : null;
  }

  if (!items.length) return null;

  if (mode === "inline") {
    if (!latest) return null;
    if (!shouldShowInline) return null;

    return (
      <Card className="p-5">
        <WhatsNewEntry item={latest} maxBullets={maxBullets} mode="inline" />
        <div className="mt-4">
          <Button
            variant="ghost"
            shape="lg"
            onClick={() => markSeen(latest.tag)}
            className="w-full sm:w-auto"
          >
            {t("whatsNew.gotIt", "Got it")}
          </Button>
        </div>
      </Card>
    );
  }


  return (
    <Card className="p-6">
      <div className="space-y-8">
        {items.map((item, idx) => (
          <div key={item.tag}>
            <WhatsNewEntry
              item={item}
              maxBullets={maxBullets}
              mode="full"
              onMarkSeen={markSeen}
            />
            {idx !== items.length - 1 ? (
              <div className="mt-6 border-t border-border" />
            ) : null}
          </div>
        ))}
      </div>
    </Card>
  );
};
