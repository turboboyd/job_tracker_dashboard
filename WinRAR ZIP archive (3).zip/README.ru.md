# 🚀 Job Tracker Dashboard

Современное веб-приложение на **React + TypeScript** для организации и контроля процесса поиска работы.

---

## 🎯 Цель проекта

Демонстрация навыков frontend-разработки:

- Архитектурный подход
- Работа с глобальным состоянием
- Интеграция с Firebase
- Чистая структура проекта
- Автоматизированные проверки качества кода

---

## ✨ Основные возможности

🔐 Авторизация через Firebase (Google + Email/Password)

📊 Дашборд с аналитикой

📂 Управление циклами поиска работы

📄 Фильтрация и пагинация вакансий

📌 Kanban-доска с drag & drop

🌍 Поддержка EN / RU / DE

🎨 Светлая и тёмная тема

🧪 Проверки качества кода

---

## 🛠 Технологии

React, TypeScript, Redux Toolkit, React Router  
Tailwind CSS, Radix UI, Framer Motion  
Formik, Yup  
Firebase Auth, Firestore  
Webpack, ESLint

---

## ⚙️ Запуск

npm install  
npm run dev  

Создать `.env` с Firebase-переменными.

---

Лицензия: ISC
